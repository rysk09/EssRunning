package model;

public class CalcDist {
	public double calc(double weight, double kcal) {
		return kcal / weight;
	}
}
